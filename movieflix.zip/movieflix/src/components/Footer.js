import React from 'react'

export default function Footer() {
  return (
      <>
          <div className="footer bg-danger bg-gradient">
              <h5>&copy; All rights reserved to Movieflix</h5>
        </div>
      </>
  )
}
