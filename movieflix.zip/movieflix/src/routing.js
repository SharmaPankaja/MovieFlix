import React from "react";

import { createBrowserRouter } from "react-router-dom";
import App from "./App";
import PopularMovies from "./components/PopularMovies";
import UpcomingMovies from "./components/UpcomingMovies";
import TopRatedMovies from "./components/TopRatedMovies";
import Search from "./components/Search";
import MovieDetails from "./components/MovieDetails";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,

    children: [
      {
        path: "/popular",
        element: <PopularMovies />,
      },
      {
        path: "/upcoming",
        element: <UpcomingMovies />,
      },
      {
        path: "/toprated",
        element: <TopRatedMovies />,
      },
      {
        path: "/search",
        element: <Search />,
      },
      {
        path: "/movie",
        element: <MovieDetails />,
      },
    ],
  },
]);

export default router;